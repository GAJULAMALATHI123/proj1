# IT Asset Lifecycle Manager (CAP + Fiori Elements)
npm install && cds watch  -> http://localhost:4004 (users: admin/manager/user, empty password)
Next: Dashboard (analytical cards on AssetManagerService.KPIs), PDF export/email, mta.yaml (cds add mta,hana,xsuaa,html5-repo).
