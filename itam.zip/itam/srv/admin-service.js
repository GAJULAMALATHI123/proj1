const cds = require('@sap/cds');
module.exports = class AssetAdminService extends cds.ApplicationService {
  init() {
    const { Assets, Employees, Assignments, MaintenanceRecords, History, Archive } = this.entities;
    const today = () => new Date().toISOString().slice(0, 10);

    // Ledger + archive are immutable
    this.before(['UPDATE', 'DELETE', 'CREATE'], [History, Archive], r => r.reject(405, 'Ledger is immutable'));

    // FR-001 / FR-016: unique tag/serial, mandatory fields, initial status
    this.before('CREATE', Assets, async req => {
      const d = req.data; d.status = 'AVAILABLE';
      const dup = await SELECT.one.from(Assets).where({ asset_tag: d.asset_tag }).or({ serial_number: d.serial_number });
      if (dup) req.reject(409, 'Asset tag or serial number already exists');
      const cat = await SELECT.one.from('itam.AssetCategories').where({ asset_category_id: d.category_asset_category_id });
      if (cat && cat.active === false) req.reject(400, 'Category is inactive');
    });
    // FR-027: no delete of department with employees
    this.before('DELETE', 'Departments', async req => {
      const n = await SELECT.one.from(Employees).columns('count(*) as c').where({ dept_dept_id: req.data.dept_id });
      if (n.c) req.reject(400, 'Department is referenced by employees; deactivate instead');
    });

    const load = async (req, allowed) => {
      const id = req.params[0].asset_id ?? req.params[0];
      const a = await SELECT.one.from(Assets).where({ asset_id: id });
      if (!a) req.reject(404, 'Asset not found');
      if (!allowed.includes(a.status)) req.reject(400, `Action not allowed in status ${a.status}`);
      return a;
    };
    const log = (asset_ID, action, from, to, remarks, req) => INSERT.into(History).entries({
      asset_asset_id: asset_ID, action, from_employee_employee_id: from, to_employee_employee_id: to,
      transition_date: new Date().toISOString(), actor: req.user.id, remarks });
    const activeEmp = async (id, req) => {
      const e = await SELECT.one.from(Employees).where({ employee_id: id });
      if (!e || e.status !== 'ACTIVE') req.reject(400, 'Employee not found or not active');
    };

    this.on('assign', Assets, async req => {   // FR-003, FR-004
      const a = await load(req, ['AVAILABLE']); const { employee_id, distribution_date, expected_return_date } = req.data;
      await activeEmp(employee_id, req);
      if (distribution_date < a.purchase_date) req.reject(400, 'Distribution date cannot be earlier than procurement date');
      await INSERT.into(Assignments).entries({ asset_asset_id: a.asset_id, employee_employee_id: employee_id,
        assigned_date: distribution_date, expected_return_date, assignment_status: 'ACTIVE' });
      await UPDATE(Assets, a.asset_id).with({ status: 'ASSIGNED', current_holder_employee_id: employee_id,
        first_distribution_date: a.first_distribution_date || distribution_date });
      await log(a.asset_id, 'ASSIGN', null, employee_id, null, req);
    });
    this.on('transfer', Assets, async req => { // FR-005
      const a = await load(req, ['ASSIGNED']); const { new_employee_id, transfer_date, remarks } = req.data;
      await activeEmp(new_employee_id, req);
      if (transfer_date < a.purchase_date) req.reject(400, 'Transfer date cannot be earlier than procurement date');
      await UPDATE(Assignments).set({ assignment_status: 'TRANSFERRED', actual_return_date: transfer_date })
        .where({ asset_asset_id: a.asset_id, assignment_status: 'ACTIVE' });
      await INSERT.into(Assignments).entries({ asset_asset_id: a.asset_id, employee_employee_id: new_employee_id,
        assigned_date: transfer_date, assignment_status: 'ACTIVE' });
      await UPDATE(Assets, a.asset_id).with({ current_holder_employee_id: new_employee_id });
      await log(a.asset_id, 'TRANSFER', a.current_holder_employee_id, new_employee_id, remarks, req);
    });
    this.on('returnAsset', Assets, async req => { // FR-006
      const a = await load(req, ['ASSIGNED']); const { return_date, remarks } = req.data;
      await UPDATE(Assignments).set({ assignment_status: 'RETURNED', actual_return_date: return_date })
        .where({ asset_asset_id: a.asset_id, assignment_status: 'ACTIVE' });
      await UPDATE(Assets, a.asset_id).with({ status: 'AVAILABLE', current_holder_employee_id: null });
      await log(a.asset_id, 'RETURN', a.current_holder_employee_id, null, remarks, req);
    });
    this.on('sendToMaintenance', Assets, async req => { // FR-008
      const a = await load(req, ['AVAILABLE', 'ASSIGNED']); const { type, issue, vendor_id } = req.data;
      await INSERT.into(MaintenanceRecords).entries({ asset_asset_id: a.asset_id, type, issue,
        service_vendor_vendor_id: vendor_id, reported_date: today(), status: 'OPEN' });
      await UPDATE(Assets, a.asset_id).with({ status: 'MAINTENANCE' });
      await log(a.asset_id, 'MAINTENANCE_START', a.current_holder_employee_id, null, issue, req);
    });
    this.on('completeMaintenance', Assets, async req => { // FR-009
      const a = await load(req, ['MAINTENANCE']);
      await UPDATE(MaintenanceRecords).set({ status: 'COMPLETED', completed_date: today(), resolution: req.data.resolution, cost: req.data.cost })
        .where({ asset_asset_id: a.asset_id, status: 'OPEN' });
      await UPDATE(Assets, a.asset_id).with({ status: a.current_holder_employee_id ? 'ASSIGNED' : 'AVAILABLE' });
      await log(a.asset_id, 'MAINTENANCE_END', null, a.current_holder_employee_id, req.data.resolution, req);
    });
    this.on('retire', Assets, async req => { // FR-010
      const a = await load(req, ['AVAILABLE', 'MAINTENANCE']);
      if (a.current_holder_employee_id) req.reject(400, 'Assigned asset cannot be retired');
      if (!req.data.reason) req.reject(400, 'Reason is mandatory');
      await UPDATE(Assets, a.asset_id).with({ status: 'RETIRED' });
      await log(a.asset_id, 'RETIRE', null, null, `${req.data.reason} (${req.data.disposal_method || '-'})`, req);
    });
    this.on('archive', Assets, async req => { // FR-011, FR-012
      const a = await SELECT.one.from(Assets).where({ asset_id: req.params[0].asset_id ?? req.params[0] });
      if (a.status === 'ASSIGNED' || a.current_holder_employee_id) req.reject(400, 'Return the asset before archiving');
      if (a.status !== 'RETIRED') req.reject(400, 'Only RETIRED assets can be archived');
      await INSERT.into(Archive.name.replace('AssetAdminService.Archive', 'itam.ArchiveRecords')).entries({
        asset_asset_id: a.asset_id, archived_at: new Date().toISOString(), archived_by: req.user.id, reason: req.data.reason });
      await UPDATE(Assets, a.asset_id).with({ status: 'ARCHIVED' });
      await log(a.asset_id, 'ARCHIVE', null, null, req.data.reason, req);
    });
    return super.init();
  }
};
