using itam from '../db/schema';

@path: '/odata/v4/admin' @requires: 'Admin'
service AssetAdminService {
  entity Assets as projection on itam.Assets actions {
    action assign(employee_id : String, distribution_date : Date, expected_return_date : Date);
    action transfer(new_employee_id : String, transfer_date : Date, remarks : String);
    action returnAsset(return_date : Date, remarks : String);
    action sendToMaintenance(type : String, issue : String, vendor_id : String);
    action completeMaintenance(resolution : String, cost : Decimal(12,2));
    action retire(reason : String, retire_date : Date, disposal_method : String);
    action archive(reason : String);
  };
  entity Employees as projection on itam.Employees;
  entity Departments as projection on itam.Departments;
  entity Categories as projection on itam.AssetCategories;
  entity Vendors as projection on itam.Vendors;
  entity Assignments as projection on itam.AssetAssignments;
  entity MaintenanceRecords as projection on itam.MaintenanceRecords;
  @readonly entity History as projection on itam.OwnershipLedgers;
  @readonly entity Archive as projection on itam.ArchiveRecords;
}

@path: '/odata/v4/user' @requires: 'User'
service AssetUserService {
  @readonly entity Assets as projection on itam.Assets;
  @readonly entity AssetAssignments as projection on itam.AssetAssignments;
  @readonly entity AssetHistory as projection on itam.OwnershipLedgers;
}

@path: '/odata/v4/manager' @requires: 'Manager'
service AssetManagerService {
  @readonly entity Assets as projection on itam.Assets;
  @readonly entity Assignments as projection on itam.AssetAssignments;
  @readonly entity History as projection on itam.OwnershipLedgers;
  @readonly entity Maintenance as projection on itam.MaintenanceRecords;
  @readonly entity KPIs as select from itam.Assets { key status, count(*) as total : Integer, sum(purchase_cost) as value : Decimal(15,2) } group by status;
}
