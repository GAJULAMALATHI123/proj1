using AssetAdminService as S from './services';
annotate S.Assets with @(
  UI.SelectionFields: [asset_tag, serial_number, category_asset_category_id, status, current_holder_employee_id, vendor_vendor_id, location],
  UI.HeaderInfo: { TypeName: 'Asset', TypeNamePlural: 'Assets', Title: { Value: asset_tag }, Description: { Value: model } },
  UI.LineItem: [
    { Value: asset_tag }, { Value: serial_number }, { Value: model }, { Value: category.name, Label: 'Category' },
    { Value: current_holder.full_name, Label: 'Holder' }, { Value: location },
    { Value: status, Criticality: 0 },
    { $Type: 'UI.DataFieldForAction', Action: 'AssetAdminService.assign', Label: 'Assign' },
    { $Type: 'UI.DataFieldForAction', Action: 'AssetAdminService.transfer', Label: 'Transfer' },
    { $Type: 'UI.DataFieldForAction', Action: 'AssetAdminService.returnAsset', Label: 'Return' },
    { $Type: 'UI.DataFieldForAction', Action: 'AssetAdminService.sendToMaintenance', Label: 'Send to Maintenance' },
    { $Type: 'UI.DataFieldForAction', Action: 'AssetAdminService.completeMaintenance', Label: 'Complete Maintenance' },
    { $Type: 'UI.DataFieldForAction', Action: 'AssetAdminService.retire', Label: 'Retire' },
    { $Type: 'UI.DataFieldForAction', Action: 'AssetAdminService.archive', Label: 'Archive' } ],
  UI.Facets: [
    { $Type: 'UI.ReferenceFacet', Label: 'General', Target: '@UI.FieldGroup#General' },
    { $Type: 'UI.ReferenceFacet', Label: 'Procurement', Target: '@UI.FieldGroup#Proc' },
    { $Type: 'UI.ReferenceFacet', Label: 'Assignments', Target: 'assignments/@UI.LineItem' },
    { $Type: 'UI.ReferenceFacet', Label: 'Maintenance', Target: 'maintenance/@UI.LineItem' },
    { $Type: 'UI.ReferenceFacet', Label: 'History', Target: 'ledger/@UI.LineItem' } ],
  UI.FieldGroup #General: { Data: [{ Value: asset_tag }, { Value: serial_number }, { Value: model }, { Value: category_asset_category_id }, { Value: status }, { Value: current_holder_employee_id }, { Value: location }] },
  UI.FieldGroup #Proc: { Data: [{ Value: vendor_vendor_id }, { Value: purchase_date }, { Value: purchase_cost }, { Value: warranty_expiry }, { Value: first_distribution_date }] }
);
annotate S.Assets with { status @readonly; current_holder @readonly; first_distribution_date @readonly };
annotate S.Assignments with @UI.LineItem: [{ Value: employee_employee_id }, { Value: assigned_date }, { Value: expected_return_date }, { Value: actual_return_date }, { Value: assignment_status }];
annotate S.MaintenanceRecords with @UI.LineItem: [{ Value: type }, { Value: issue }, { Value: reported_date }, { Value: completed_date }, { Value: status }, { Value: cost }];
annotate S.History with @UI.LineItem: [{ Value: transition_date }, { Value: action }, { Value: from_employee_employee_id }, { Value: to_employee_employee_id }, { Value: actor }, { Value: remarks }];
