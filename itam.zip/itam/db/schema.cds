namespace itam;
using { managed } from '@sap/cds/common';

entity Departments : managed {
  key dept_id : String(10); name : String(80) @mandatory; cost_center : String(20); active : Boolean default true;
}
entity Employees : managed {
  key employee_id : String(10); full_name : String(100) @mandatory; email : String(120);
  phone : String(20); location : String(60); status : String(10) default 'ACTIVE';
  dept : Association to Departments;
}
entity AssetCategories : managed {
  key asset_category_id : String(10); name : String(60) @mandatory; lifespan_months : Integer; active : Boolean default true;
}
entity Vendors : managed {
  key vendor_id : String(10); name : String(100) @mandatory; email : String(120);
}
entity Assets : managed {
  key asset_id : UUID;
  asset_tag : String(30) @mandatory; serial_number : String(60) @mandatory;
  category : Association to AssetCategories @mandatory;
  vendor : Association to Vendors;
  model : String(80); purchase_date : Date @mandatory; purchase_cost : Decimal(12,2);
  warranty_expiry : Date; first_distribution_date : Date;
  status : String(12) default 'AVAILABLE'; // AVAILABLE|ASSIGNED|MAINTENANCE|RETIRED|ARCHIVED
  location : String(60);
  current_holder : Association to Employees;
  assignments : Composition of many AssetAssignments on assignments.asset = $self;
  ledger : Composition of many OwnershipLedgers on ledger.asset = $self;
  maintenance : Composition of many MaintenanceRecords on maintenance.asset = $self;
  archive : Composition of many ArchiveRecords on archive.asset = $self;
}
entity AssetAssignments : managed {
  key assignment_id : UUID; asset : Association to Assets; employee : Association to Employees;
  assigned_date : Date; expected_return_date : Date; actual_return_date : Date;
  assignment_status : String(10) default 'ACTIVE'; // ACTIVE|TRANSFERRED|RETURNED
}
entity OwnershipLedgers {
  key ledger_id : UUID; asset : Association to Assets;
  action : String(20); from_employee : Association to Employees; to_employee : Association to Employees;
  transition_date : Timestamp; actor : String(100); remarks : String(255);
}
entity MaintenanceRecords : managed {
  key maintenance_id : UUID; asset : Association to Assets; service_vendor : Association to Vendors;
  type : String(30); issue : String(255); reported_date : Date; completed_date : Date;
  status : String(12) default 'OPEN'; cost : Decimal(12,2); resolution : String(255);
}
entity ArchiveRecords {
  key archive_id : UUID; asset : Association to Assets; archived_at : Timestamp; archived_by : String(100);
  reason : String(255); disposal_method : String(40);
}
